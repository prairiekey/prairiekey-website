import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'PrairieKey Property Management | Winnipeg Property Management',
  description: 'Professional property management in Winnipeg and surrounding areas. Tenant placement, rent collection, inspections, maintenance coordination, and owner reporting.',
  metadataBase: new URL('https://prairiekeypropertymgt.ca'),
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
