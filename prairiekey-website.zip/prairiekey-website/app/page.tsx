import Image from 'next/image';
import { Building2, ClipboardCheck, Wrench, FileText, ShieldCheck, Banknote, MapPin, Phone, Mail } from 'lucide-react';

const services = [
  ['Tenant Placement', 'Professional marketing, showings, screening, references, and lease preparation.', Building2],
  ['Rent Collection', 'Reliable rent collection, payment monitoring, and owner updates.', Banknote],
  ['Maintenance', 'Trusted contractor coordination, preventative care, and emergency response.', Wrench],
  ['Inspections', 'Move-in, move-out, and routine inspections to help protect your investment.', ClipboardCheck],
  ['Owner Reporting', 'Clear monthly statements, expense tracking, and transparent communication.', FileText],
  ['Full Management', 'End-to-end support for landlords who want stress-free ownership.', ShieldCheck],
];

export default function Home() {
  return (
    <main>
      <nav className="nav">
        <div className="container nav-inner">
          <a className="logo" href="#top">
            <Image src="/images/prairiekey-logo.png" alt="PrairieKey Property Management logo" width={90} height={60} />
            <span>PrairieKey</span>
          </a>
          <div className="nav-links">
            <a href="#services">Services</a>
            <a href="#owners">Owners</a>
            <a href="#process">Process</a>
            <a href="#assessment">Assessment</a>
            <a href="#contact">Contact</a>
            <a className="btn btn-gold" href="#assessment">Free Consultation</a>
          </div>
        </div>
      </nav>

      <section id="top" className="hero">
        <div className="container">
          <div className="eyebrow">Winnipeg & Surrounding Areas</div>
          <h1>Your Property. Our Priority.</h1>
          <p>Premium property management that protects your investment, maximizes rental income, and delivers peace of mind.</p>
          <div className="actions">
            <a className="btn btn-gold" href="#assessment">Request a Free Consultation</a>
            <a className="btn btn-outline" href="#services">View Our Services</a>
          </div>
        </div>
      </section>

      <section id="services" className="section">
        <div className="container">
          <div className="section-title">
            <h2>Complete Property Management Services</h2>
            <p>We handle the daily details so property owners can enjoy the benefits of real estate ownership without the stress.</p>
          </div>
          <div className="grid">
            {services.map(([title, description, Icon]) => (
              <div className="card" key={title as string}>
                <div className="icon"><Icon size={24} /></div>
                <h3>{title}</h3>
                <p>{description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="owners" className="section">
        <div className="container split">
          <div className="photo" aria-label="Modern residential property" />
          <div className="navy-panel">
            <div className="eyebrow">Why Choose PrairieKey</div>
            <h2>Built for owners who want professional, reliable service.</h2>
            <p>We focus on protecting your asset, finding quality tenants, responding quickly, and keeping communication clear.</p>
            <div className="list">
              <div>✓ Thorough tenant screening</div>
              <div>✓ Transparent owner reporting</div>
              <div>✓ Local Winnipeg rental market knowledge</div>
              <div>✓ Trusted maintenance and repair coordination</div>
              <div>✓ Stress-free property ownership</div>
            </div>
          </div>
        </div>
      </section>

      <section id="process" className="section">
        <div className="container">
          <div className="section-title">
            <h2>How It Works</h2>
            <p>A clear, simple process designed to get your property professionally managed with confidence.</p>
          </div>
          <div className="grid process">
            {['Free Consultation', 'Property Assessment', 'Tenant Placement', 'Ongoing Management'].map((item, index) => (
              <div className="card step" key={item}>
                <strong>Step {index + 1}</strong>
                <h3>{item}</h3>
                <p>{index === 0 ? 'We learn about your property and goals.' : index === 1 ? 'We review rent potential, condition, and strategy.' : index === 2 ? 'We market the property and screen tenants carefully.' : 'We handle rent, communication, maintenance, and reporting.'}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="assessment" className="section">
        <div className="container split">
          <div>
            <div className="eyebrow">Free Rental Assessment</div>
            <h2 style={{fontSize: '44px', color: '#0e2a47', margin: '12px 0'}}>Find out what your property could earn.</h2>
            <p style={{color: '#607085', fontSize: '18px', lineHeight: 1.7}}>Send us your property details and we’ll help you understand your rental potential and the best management approach.</p>
          </div>
          <div className="form-wrap">
            <form className="form" action="mailto:info@prairiekeypropertymgt.ca" method="post" encType="text/plain">
              <input name="name" placeholder="Full Name" required />
              <input name="phone" placeholder="Phone Number" required />
              <input name="email" type="email" placeholder="Email Address" required />
              <select name="bedrooms" defaultValue="">
                <option value="" disabled>Bedrooms</option>
                <option>1 Bedroom</option><option>2 Bedrooms</option><option>3 Bedrooms</option><option>4+ Bedrooms</option>
              </select>
              <input name="propertyAddress" placeholder="Property Address" />
              <input name="serviceArea" value="Winnipeg & Surrounding Areas" readOnly />
              <textarea name="message" placeholder="Tell us about your property" />
              <button className="btn btn-gold" type="submit">Submit Request</button>
            </form>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="section-title">
            <h2>Professional. Transparent. Local.</h2>
            <p>PrairieKey Property Management is designed for property owners who want attentive service, clear communication, and a premium management experience.</p>
          </div>
          <div className="grid">
            <div className="card"><h3>“Stress-free ownership.”</h3><p>PrairieKey handles the details so owners can focus on long-term investment success.</p></div>
            <div className="card"><h3>“Clear communication.”</h3><p>Regular updates and straightforward reporting help owners stay informed.</p></div>
            <div className="card"><h3>“Local expertise.”</h3><p>Winnipeg market knowledge helps position your rental property competitively.</p></div>
          </div>
        </div>
      </section>

      <footer id="contact" className="footer">
        <div className="container footer-grid">
          <div>
            <div className="logo"><Image src="/images/prairiekey-logo.png" alt="PrairieKey logo" width={90} height={60} /><span>PrairieKey Property Management</span></div>
            <p>Professional property management serving Winnipeg & Surrounding Areas.</p>
          </div>
          <div>
            <h3>Contact</h3>
            <ul>
              <li><Phone size={14}/> 204-407-5757</li>
              <li><Mail size={14}/> info@prairiekeypropertymgt.ca</li>
              <li><MapPin size={14}/> 337 Park West Drive, Winnipeg, MB R3Y 0V9</li>
            </ul>
          </div>
          <div>
            <h3>Quick Links</h3>
            <ul>
              <li><a href="#services">Services</a></li>
              <li><a href="#owners">Property Owners</a></li>
              <li><a href="#assessment">Free Rental Assessment</a></li>
            </ul>
          </div>
        </div>
        <div className="container copyright">© {new Date().getFullYear()} PrairieKey Property Management. All rights reserved. prairiekeypropertymgt.ca</div>
      </footer>
    </main>
  );
}
