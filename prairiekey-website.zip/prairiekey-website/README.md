# PrairieKey Property Management Website

Premium website starter for PrairieKey Property Management.

## Run locally

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Deploy

Recommended hosting: Vercel.

1. Upload this folder to GitHub.
2. Import the repo in Vercel.
3. Add your domain: prairiekeypropertymgt.ca
4. Point your DNS records to Vercel.

## Contact details included

- Phone: 204-407-5757
- Website: prairiekeypropertymgt.ca
- Email: info@prairiekeypropertymgt.ca
- Address: 337 Park West Drive, Winnipeg, MB R3Y 0V9
- Service area: Winnipeg & Surrounding Areas
